solution = output.result.solution;
tf       = solution.phase(2).time;